if GetLocale() ~= "deDE" then return end

AddonLoader.L = {
	explain = "Die Bedingungen zum Laden k\195\182nnen f\195\188r jedes Addon \195\188berschrieben werden. \195\132nderungen treten erst nach einem Neuladen des Interfaces in Kraft. Die ausgegrauten Addons in der Liste benutzen derzeit ihre Standardeinstellung zum Laden.",
	hideloading = "Lademeldungen verstecken",
	reset = "Zur\195\188cksetzen",
}
