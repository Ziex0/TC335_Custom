-- default localization in english.
AddonLoader.L = {
	explain = "You can override the Addon Loader conditions per AddOn. Overrides will only be active after reloading the UI. Greyed out AddOns in the listing are currently using their default load conditions.",
	hideloading = "Hide Loading Messages",
	reset = "Reset",
	clicktoload = "|cffeda55fClick|r to load."
}
