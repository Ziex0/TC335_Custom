if GetLocale() ~= "koKR" then return end

AddonLoader.L = {
	explain = "애드온 각각의 적재 조건을 적용할 수 있습니다. 조건 적용은 UI 재시작 후에만 동작합니다. 목록에서 회색으로 표시된 것은 현재 기본 적재 조건을 사용중인 애드온입니다.",
	hideloading = "로딩 메세지 숨기기",
	reset = "초기화",
	clicktoload = "|cffeda55f클릭|r - 로드.",
}
