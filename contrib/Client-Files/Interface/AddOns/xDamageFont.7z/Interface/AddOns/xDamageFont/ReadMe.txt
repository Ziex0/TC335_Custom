Choose your font (www.dafont.com), put it in "xDamageFont\Fonts" folder and rename it "damagefont.TTF".

By default it is "Emblem" font.