<?php

/**
 * Amount of accounts to display
 */
$config['accounts_limit'] = 5; 

/**
 * The time for the cache to expire
  */
$config['cache_time'] = '1 hour';