<?php

$config['error_message_no_characters'] = 'You must have at least one character, on any realm, to subscribe';
$config['error_message_no_lottery_started'] = 'No lottery started yet';
$config['error_message_no_staff_allowed_to_subscribe'] = 'Staff members cannot subscribe their characters';
