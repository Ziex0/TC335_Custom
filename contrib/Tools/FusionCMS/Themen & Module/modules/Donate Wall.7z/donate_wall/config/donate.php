<?php

$config['paymentwall_key'] = "";
$config['paymentwall_secret_key'] = "";
$config['paymentwall_widget_code'] = "p1_1"; // p1_1 for paymentwall_multi
