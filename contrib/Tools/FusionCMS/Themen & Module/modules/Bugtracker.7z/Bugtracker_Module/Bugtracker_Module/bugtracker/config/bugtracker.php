<?php

$config['bugtracker_limit'] = 100;