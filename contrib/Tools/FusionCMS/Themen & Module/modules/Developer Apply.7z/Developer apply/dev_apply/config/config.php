<?php

$config['realmid'] = 1;
$config['minimize_groups_by_default'] = true;
$config['questionnr'] = 8; // Define how many questions should be enabled.
$config['info1'] = "How long have you been playing on the server?";
$config['info2'] = "Have you ever been a staff member on any server before? If yes, what server and position.";
$config['info3'] = "Why do you think we should accept you as a Staff member?";
$config['info4'] = "If a player makes a ticket and say 'A another player one-hit me when I have over 120000.00000 hp', what would you do?";
$config['info5'] = "Tell us about your scripting experience. wich scripting language do you know?";
$config['info6'] = "What can we expect from you?";
$config['info7'] = "Tell us atleast 1 thing that we should fix with the server.";
$config['info8'] = "Tell us some more about your self. if you have anything else to say, say it here!";
$config['info9'] = "Contact information, whit skype name and email adress.";

// If you want to add more questions, copy one row and paste it below the other rows.  
// Then just change the 'info*' to the number that you want then change 'question*' to the amout of question.