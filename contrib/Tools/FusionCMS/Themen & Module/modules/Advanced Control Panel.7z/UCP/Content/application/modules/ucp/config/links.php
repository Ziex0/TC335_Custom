<?php

/**
 * Set the links of the UCP buttons.
 * Leave empty to disable the button!
 */
$config['ucp_vote'] = "vote";
$config['ucp_donate'] = "donate";
$config['ucp_store'] = "store";
$config['ucp_settings'] = "ucp/settings";
$config['ucp_expansion'] = "ucp/expansion";
$config['ucp_teleport'] = "teleport";
$config['ucp_gm'] = "gm";
$config['ucp_admin'] = "admin";