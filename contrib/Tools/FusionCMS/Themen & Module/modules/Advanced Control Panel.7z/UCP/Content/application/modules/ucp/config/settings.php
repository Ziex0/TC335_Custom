<?php

/**
 * Should we display a language select field on the settings page?
 */
$config['show_language_chooser'] = true;