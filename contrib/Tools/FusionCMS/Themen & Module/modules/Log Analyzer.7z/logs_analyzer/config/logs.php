<?php

$config['logs_file_path'] = 'd:/Build/logs/GM.log';
$config['last_commands_first'] = true;
$config['enable_wowhead_links'] = true;

