If you have the old folder named "logs", remove it.

The log file must be accesible by the application.
You can either acces it via http url, or direct path in case site is hosted on the same server.

If you access the logs file via http, you'd rather restrict access for host IP only, via htaccess

If you have any problems, you can email me at simion.agv@gmail.com
