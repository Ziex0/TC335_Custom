Installation and usage instructions:
https://model-changing.net/tutorials/article/106-wow-blender-studio-complete-guide/

Note that this is outdated and a replacement based on this is in development.