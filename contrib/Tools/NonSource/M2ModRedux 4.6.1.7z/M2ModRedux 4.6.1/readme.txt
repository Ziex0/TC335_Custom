M2ModRedux Redux 4.6.1 by Freeman

Compatible with WoD 6.0.3 models.

Versions:
4.6.1:
- buttons replaced by tabs.
- fake LOD auto generated (copies of 01.skin).
- Blender: no need to show and select Armature anymore to export.
- Blender scripts: updated to Blender 2.73.
- Blender scripts: Submesh real ID, better order.
- Blender scripts: added a script to hide Attachments and groups of mesh (armor, cloak, etc.)
4.6:
- fix: haircuts.
- fix: client crash.

Known bugs:
Draenei F: light faces.
Orcs M/F, gnome M(?)/F: LOD.
Tauren F: hair.
Orc M: hair and facial hair.
Pandaren M: faces/hair styles.


Thanks to Redaxle for giving the original source code.
Thanks to the Darknest community for help.

Source code: https://bitbucket.org/Fr33m4n/m2mod/src

Official thread: http://forums.darknestfantasyerotica.com/showthread.php?20464-M2mod-Redux-4.6-compatible-with-WoD-models