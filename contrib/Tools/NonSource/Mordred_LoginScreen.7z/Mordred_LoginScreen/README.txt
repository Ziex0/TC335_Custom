Source: http://www.modcraft.io/index.php?topic=8694.0

Long time no see everyone,

as some of you might know I was working on a completely new version of my "How to Loginscreen".
This one is made from scratch and compared to my old one, the old one is pretty much complete garbage.
In the end I didn't want to release it because I had no example loginscreen, but as I gave it to some that asked I decided to fuck it and just release it without example.

So... here we go:

----------------------------------------------
1.: What's new?
Beginner:
2.: The files
3.: The Tool
4.: Getting the hang of it
Advanced:
5.: How to add it to your own files?
6.: How to use them?
7.: How to edit the Buttons?
-
8.: Credits
----------------------------------------------

1.: What's new?

Only 1 file that has the code in it
A ton of improvements code wise
You can 'copy' a camera of a model to the one you want to display
Should work with every resolution possible now
Enhanced API that allows you to make scene scripts that allow you to move models or do different animations
A tool that makes creating your own loginscreen a cake walk



BEGINNER SECTION:

2.: The files

Loginscreen with XML extensions - the classic one
Newbie repack with tool - a repack that works by just extract inside wow folder and go

Loginscreen only - only has the loginscreen file in it, for projects that already did changes to xml files
LoginscreenTool only - only the LoginscreenTool file, to just add it if you already have a loginscreen

3.: The Tool



The tool does everything you would normaly have to do by hand with trial and error inside the LoginScene.lua file,
by itself, with almost no effort.

To enable the tool for your loginscreen download either the "Newbie repack with tool" which you only have to extract inside your wow directory and give it a go,
or get the "LoginscreenTool only" file, which only has the loginscreen tool in it.

If you got the "LoginscreenTool only" download, you have to open "AccountLogin.xml" and go to the end of the file,
and add:

Code: [Select]
<Script file="LSTool.lua"/>
below the other Script file.

If you have finished your loginscreen with the tool and want to disable it, you have to open "AccountLogin.xml" and go to the end of the file,
and then delete the line you added before.

4.: Getting the hand of it

After you downloaded the files (look 2.) you need to unpack them into your WoW directory (where your WoW.exe is)

If you click the "allFiles.exe" it should look like this:


Now you can open the "LoginScene.lua"-file inside the Interface/GlueXML folder.

On line 57 - 71 is everything you need to look at for editing, if you are not familiar with the Lua language, as SceneScripts can get overwhelming.
inside the sceneData table you find the general settings for your scene:
1: Time in seconds until the next scene get's triggered
2: path to the background image
change them as you need them.

After the sceneData table you find all the models for all your scenes with their settings:
1: sceneID - the model will only show on this specific sceneID
2 - 7: position, rotation, scale and alpha of the model
(Z and Scale look like they both do the same, but Z actually pushes the model further back, if you push it too far back it will vanish because it's out of render distance)
8: the Light of the model, pretty advanced, look at the light documentation inside the LoginScene.lua file, if you want to use the default light just leave it blank with "_"
9: sequence - this is the animation the model will do (may have to play around to find the right one)
10 - 11: width and height Squish - those are also used for scaling, as scaling the model itself will not scale the particles, so sometimes you have to use these two for scaling
12: the path to the model, the model needs hardcoded textures, as you can't apply skins with a method
13: referenceID - this ID doesn't need to be set unless you want to do SceneScripts (can also be left black with "_" if you want to use a cameraModel)
14: cameraModel - this one is a path too like <12>, but this model will only get used for copying it's camera

if you want to add another model to the same scene just make sure the sceneID is the same.
!! add a comma to the end of all models except the last one like this :
Code: [Select]
	{1, 0, 0, 0, 0, 1, 1, _, 1, 1, 1, "World\Scale\HumanMaleScale.mdx"},
	{1, 0, 0, 0, 0, 1, 1, _, 1, 1, 1, "World\Scale\HumanMaleScale.mdx"},
	{1, 0, 0, 0, 0, 1, 1, _, 1, 1, 1, "World\Scale\HumanMaleScale.mdx"}
The same goes for scenes !!


ADVANCED SECTION:

5.: How to add it to your own files?
You only need the "Loginscreen only" download to implement it!


<AccountLogin.xml> changes:
line 93:
Code: [Select]
	<ModelFFX name="AccountLogin" toplevel="true" parent="GlueParent" setAllPoints="true" enableKeyboard="true" hidden="true" fogNear="0" fogFar="1200" glow="0.08">
to
Code: [Select]
	<Frame name="AccountLogin" toplevel="true" parent="GlueParent" setAllPoints="true" enableKeyboard="true" frameStrata="HIGH" hidden="true">
line 2501 - 2502:
Code: [Select]
			</Scripts>
		<FogColor r="0.25" g="0.06" b="0.015"/>
	</ModelFFX>
to
Code: [Select]
			<OnUpdate>
				LoginScreen_OnUpdate(self, elapsed);
			</OnUpdate>
		</Scripts>
	</Frame>
at the end of the file above "</UI>" and beneath "</Frame>" add:
Code: [Select]
	<Script file="LoginScene.lua"/>

<AccountLogin.lua> changes:
delete line 29 - 38:
Code: [Select]
	self:SetCamera(0);
	self:SetSequence(0);
	
	if (IsStreamingTrial()) then
		AccountLoginCinematicsButton:Disable();
		AccountLogin:SetModel("Interface\Glues\Models\UI_MainMenu\UI_MainMenu.m2");
	else
		AccountLogin:SetModel("Interface\Glues\Models\UI_MainMenu_Northrend\UI_MainMenu_Northrend.m2");
	end
delete line 41 - 43:
Code: [Select]
	self:SetSequence(0);
	PlayGlueMusic(CurrentGlueMusic);
	PlayGlueAmbience(GlueAmbienceTracks["DARKPORTAL"], 4.0);

6.: How to use them?

Now you have everything set up, but how do you use it you might ask.
This time around I made a whole documentary inside the LoginScene.lua file, that has everything that you need to know about what to do.
You can also find it HERE.


7.: How to edit the Buttons?

To edit the buttons you can get the 3 needed .blp files from this path:
Code: [Select]
Interface/GLUES/COMMON/
inside the locale-enGB.MPQ or your localization you are useing.
you need to get these three files:
Code: [Select]
Glue-Panel-Button-Up-Blue.blp
Glue-Panel-Button-Down-Blue.blp
Glue-Panel-Button-Highlight-Blue.blp
Now you can convert them and edit them as you want.
Make sure you change the alpha-channel to your new button styles.


8.: Credits:
   Soldan - helping me with all the model work
   Chase - finding a method to copy cameras on the fly
   Stoneharry - bringing me to the conclusion that blizzard frames are never fullscreen, so it works now with every resolution
   Blizzard - for making it almost impossible to make it work properly

~Mordred