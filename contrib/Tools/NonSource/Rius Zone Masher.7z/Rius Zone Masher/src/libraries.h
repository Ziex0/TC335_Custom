#ifndef __LIBRARIES
#define __LIBRARIES

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <sstream>

#include "list.h"

#endif
