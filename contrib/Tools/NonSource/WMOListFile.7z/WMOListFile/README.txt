Version: 1.0

If you want to get list of all BLP and M2/MDX files which are used in WMOs (can be used also for ADTs, files used by M2s and so on):
- Export your WMOs into some work folder.
- Copy .bat and .exe into work folder with your WMOs (or into some folder where folders with WMOs are).
- Run .bat file.

If you want to extract all files used by WMOs (and doodads in their doodad sets) from MPQs:
- Make copies of your MPQs.
- Use FuckItUp on them.
- Open MPQEditor, go to File menu, choose Open MPQ(s) With Options...
- Select FuckItUped MPQs.
- Click on Merged mode.
- Click on ... button next to Additional listfile files
- Use WMOListFile.txt as listfile.
- Select all folders (don't select Filexxxx... files) and press ctrl+e, choose your work folder.
- Execute .bat file in your work folder with extracted files again and repeat whole procedure, to get BLPs of exported M2s from doodad sets.
- Profit.


Coded by Amaroth.

Contacts:
Skype striker159753
PM on http://www.model-changing.net/
PM on http://modcraft.superparanoid.de/