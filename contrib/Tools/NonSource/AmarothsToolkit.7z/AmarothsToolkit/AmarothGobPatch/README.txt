Version 2
- I've found out that my first release had slight bug, some models were missing. This version should fix that!

1. If you don't have it, google for WoW.exe crack which enables using custom patches.
2. Choose if you want to use "light" version 1 or "full" version 2. Version 2 includes also huge amount of completely useless objects without textures, but you may want to use some of them.
3. Place Patch-4 from version you have chosen into your ../WoW/Data/
4. Upload or copy .DBC file from version you have chosen into your server's ../data/dbc/
5. Execute SQL dump from version you have chosen on your World database
6. (optional) Feel free to rename patch-4 to patch-[one ASCII letter] if you want to, or merge it with any other custom patch of yours if you know how to do that.
7. Restart your server (and game client).
8. ???
9. Profit.

Now any ("light" version excludes mostly useless ones) M2 or WMO object you can find in WoW Model Viewer has gameobject version with the same name in game.
Note that players need to have both cracked WoW.exe and patch-4.mpq to be able to see any object with [AmPatch] in name. Otherwise they will see just cube.



Author: Amaroth