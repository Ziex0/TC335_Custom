How to use:
- Run ADT_Adder.exe.
- Use WotLKTemplateADT_0_0.adt as the Source.
- Fill in your Map Name and XY ADT coords you want to cover with copies of those ADTs.
- Click Start creation.
- Copy offsetfix.bat and OffsetFix.exe into directory with your new ADT files.
- Run offsetfix.bat